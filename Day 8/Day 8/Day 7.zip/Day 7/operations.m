function [add,sub,mul]=operations(a,b)
add=a+b;
sub=a-b;
mul=a*b;
end
