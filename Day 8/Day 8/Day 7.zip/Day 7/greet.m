function greet(name)
disp(['Hello',name]);
end