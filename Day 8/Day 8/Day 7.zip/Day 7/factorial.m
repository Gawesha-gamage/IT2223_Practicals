function fact=factorial(n)
choice = input('enter a number ');
 fact=1;

end
end
