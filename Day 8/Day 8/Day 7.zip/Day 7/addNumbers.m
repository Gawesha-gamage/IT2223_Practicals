function sum =addNumbers(x,y)%input parameters
sum=x+y;
end
%this function input and output