function myFunction()
disp('hello, this function has no inpus or outputs')
end